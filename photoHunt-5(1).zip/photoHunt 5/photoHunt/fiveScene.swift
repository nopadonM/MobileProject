//
//  fiveScene.swift
//  photoHunt
//
//  Created by student on 13/7/2561 BE.
//  Copyright © 2561 student. All rights reserved.
//
import UIKit
import SpriteKit
import GameplayKit
import AVFoundation

class fiveScene: GameViewController {
    var seconds = 60
    var timer = Timer()
    var item1 = 0
    var musiccheck = 0
    var score = GameViewController.globalvar.score
    var mainmusic: AVAudioPlayer = AVAudioPlayer()
    var winmusic: AVAudioPlayer = AVAudioPlayer()
    var losemusic: AVAudioPlayer = AVAudioPlayer()
    var hurrymusic: AVAudioPlayer = AVAudioPlayer()
    @IBOutlet var alert: UILabel!
    @IBOutlet var pic1_1: UIButton!
    @IBOutlet var pic2_1: UIButton!
    @IBOutlet var pic3_1: UIButton!
    @IBOutlet var pic4_1: UIButton!
    @IBOutlet var pic5_1: UIButton!
    @IBOutlet var pic1_2: UIButton!
    @IBOutlet var pic2_2: UIButton!
    @IBOutlet var pic3_2: UIButton!
    @IBOutlet var pic4_2: UIButton!
    @IBOutlet var pic5_2: UIButton!
    @IBOutlet var newgame: UIButton!
    @IBOutlet var nextgame: UIButton!
    var checkPic:Int = 0
    var picture1:Int = 0
    var picture2:Int = 0
    var picture3:Int = 0
    var picture4:Int = 0
    var picture5:Int = 0
    @IBOutlet weak var scorelb: UILabel!
    
    @IBOutlet var end: UIImageView!
    @IBOutlet var countdown: UILabel!
    @IBOutlet var itemtime: UIButton!
    func runTimer(){
        timer = Timer.scheduledTimer(timeInterval: 1, target: self,   selector: (#selector(fiveScene.updateTimer)), userInfo: nil, repeats: true)
    }
    @objc func updateTimer() {
        seconds -= 1     //This will decrement(count down)the seconds.
        countdown.text = "\(seconds)" //This will update the label.
        if(seconds <= 15 && musiccheck == 0){
            mainmusic.stop()
            hurrymusic.play()
            musiccheck = 1
        }
        if(seconds <= 0 && musiccheck == 1){
            end.image = UIImage(named: "lose")
            end.isHidden = false
            newgame.isHidden = false
            hurrymusic.stop()
            losemusic.play()
            GameViewController.globalvar.score = 0
            timer.invalidate()
        }
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let main = Bundle.main.path(forResource: "maintheme", ofType: ".mp3")
        do{
            try mainmusic =  AVAudioPlayer(contentsOf: URL (fileURLWithPath: main!))
        }
        catch{
            print(error)
        }
        let win = Bundle.main.path(forResource: "win", ofType: ".mp3")
        do{
            try winmusic =  AVAudioPlayer(contentsOf: URL (fileURLWithPath: win!))
        }
        catch{
            print(error)
        }
        let lose = Bundle.main.path(forResource: "lose", ofType: ".mp3")
        do{
            try losemusic =  AVAudioPlayer(contentsOf: URL (fileURLWithPath: lose!))
        }
        catch{
            print(error)
        }
        let hurry = Bundle.main.path(forResource: "hurry", ofType: ".mp3")
        do{
            try hurrymusic =  AVAudioPlayer(contentsOf: URL (fileURLWithPath: hurry!))
        }
        catch{
            print(error)
        }
        
        mainmusic.play()
        
        
        
        if let view = self.view as! SKView? {
            
            if let scene = SKScene(fileNamed: "Scene_3") {
                
                scene.scaleMode = .aspectFill
                
                
                view.presentScene(scene)
            }
            
            view.ignoresSiblingOrder = true
            view.showsFPS = true
            view.showsNodeCount = true
            newgame.isHidden = true
            nextgame.isHidden = true
            countdown.text = "60"
            scorelb.text = "Score:\(score)"
            runTimer()
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    @IBAction func op1(_ sender: Any) {
        if(picture1 == 0){
            pic1_1.setImage(UIImage(named: "circle.png"), for:UIControlState())
            pic1_2.setImage(UIImage(named: "circle.png"), for:UIControlState())
            checkPic += 1;
            picture1 = 1
            score += 100
            scorelb.text = "Score:\(score)"
        }
        if(checkPic == 5){
            end.image = UIImage(named: "win")
            itemtime.isHidden = true
            nextgame.isHidden = false
            end.isHidden = false
            timer.invalidate()
            GameViewController.globalvar.score = self.score
            
            if(musiccheck == 1){
                hurrymusic.stop()
            }
            else{
                mainmusic.stop()
            }
            winmusic.play()
        }
    }
    
    @IBAction func op2(_ sender: Any) {
        if(picture2 == 0){
            pic2_1.setImage(UIImage(named: "circle.png"), for:UIControlState())
            pic2_2.setImage(UIImage(named: "circle.png"), for:UIControlState())
            checkPic += 1;
            picture2 = 1
            score += 100
            scorelb.text = "Score:\(score)"
        }
        if(checkPic == 5){
            end.image = UIImage(named: "win")
            itemtime.isHidden = true
            nextgame.isHidden = false
            end.isHidden = false
            timer.invalidate()
            GameViewController.globalvar.score = self.score
            if(musiccheck == 1){
                hurrymusic.stop()
            }
            else{
                mainmusic.stop()
            }
            winmusic.play()
        }
        
    }
    
    @IBAction func op3(_ sender: Any) {
        if(picture3 == 0){
            pic3_1.setImage(UIImage(named: "circle.png"), for:UIControlState())
            pic3_2.setImage(UIImage(named: "circle.png"), for:UIControlState())
            checkPic += 1;
            picture3 = 1
            score += 100
           scorelb.text = "Score:\(score)"
        }
        if(checkPic == 5){
            end.image = UIImage(named: "win")
            itemtime.isHidden = true
            nextgame.isHidden = false
            end.isHidden = false
            timer.invalidate()
            GameViewController.globalvar.score = self.score
            if(musiccheck == 1){
                hurrymusic.stop()
            }
            else{
                mainmusic.stop()
            }
            winmusic.play()
        }
    }
    
    @IBAction func op4(_ sender: Any) {
        if(picture4 == 0){
            pic4_1.setImage(UIImage(named: "circle.png"), for:UIControlState())
            pic4_2.setImage(UIImage(named: "circle.png"), for:UIControlState())
            checkPic += 1;
            picture4 = 1
            score += 100
           scorelb.text = "Score:\(score)"
        }
        if(checkPic == 5){
            end.image = UIImage(named: "win")
            itemtime.isHidden = true
            nextgame.isHidden = false
            end.isHidden = false
            timer.invalidate()
            GameViewController.globalvar.score = self.score
            if(musiccheck == 1){
                hurrymusic.stop()
            }
            else{
                mainmusic.stop()
            }
            winmusic.play()
        }

    }
    
    @IBAction func stop(_ sender: Any) {
        winmusic.stop()
    }
    @IBAction func op5(_ sender: Any) {
        if(picture5 == 0){
            pic5_1.setImage(UIImage(named: "circle.png"), for:UIControlState())
            pic5_2.setImage(UIImage(named: "circle.png"), for:UIControlState())
            checkPic += 1;
            picture5 = 1
            score += 100
            scorelb.text = "Score:\(score)"
        }
        if(checkPic == 5){
            end.image = UIImage(named: "win")
            itemtime.isHidden = true
            nextgame.isHidden = false
            end.isHidden = false
            timer.invalidate()
            GameViewController.globalvar.score = self.score
            if(musiccheck == 1){
                hurrymusic.stop()
            }
            else{
                mainmusic.stop()
            }
            winmusic.play()
        }
    }
    
    @IBAction func item(_ sender: Any) {
        func correct(){
            self.alert.text = "คำตอบถูกต้อง ได้รับโบนัสพิเศษ"
            self.alert.backgroundColor = UIColor.black
            self.alert.textColor = UIColor.white
        }
        func incorrect(){
            self.alert.text = "คำตอบไม่ถูกต้อง ไม่ได้รับโบนัสพิเศษ"
            self.alert.backgroundColor = UIColor.black
            self.alert.textColor = UIColor.white
        }
        
        
        
        
        func Random() {
            var RandomNumber = arc4random() % 20
            RandomNumber += 1
            switch (RandomNumber) {
            case 1:
                let alertController = UIAlertController(title: "คำถาม",message: "ผู้สูงอายุจำเป็นต้องออกกำลังอย่างต่อเนื่องและสม่ำเสมอ อย่างน้อยสัปดาหฺ์ละกี่ครั้ง", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "สัปดาห์ละ 2-3 ครั้ง", style: .default , handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                    
                }))
                alertController.addAction(UIAlertAction(title: "สัปดาห์ละ 1-2 ครั้ง", style: .default , handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "สัปดาห์ละ 4-5 ครั้ง", style: .default , handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "สัปดาห์ละ 3-4 ครั้ง", style: .default , handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 2:
                let alertController = UIAlertController(title: "คำถาม",message: "โรคทาลัสซีเมียหรือเรียกอีกอย่างว่าโรคอะไร", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "โรคโลหิตจาง", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.addAction(UIAlertAction(title: "โรคไข้เลือดออก", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "โรคเบาหวาน", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "โรคไต", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 3:
                let alertController = UIAlertController(title: "คำถาม",message: "เบี้ยยังชีพผู้สูงอายุจะให้กับบุคคลที่มีอายุกี่ปีขึ้นไป", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "50", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "55", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "60", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.addAction(UIAlertAction(title: "65", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 4:
                let alertController = UIAlertController(title: "คำถาม",message: "ช่วงอายุ 70-79 ปี จะได้รับเบี้ยยังชีพผู้สูงอายุเท่าไร", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "500 บาทต่อเดือน", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "600 บาทต่อเดือน", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "700 บาทต่อเดือน", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.addAction(UIAlertAction(title: "800 บาทต่อเดือน", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 5:
                let alertController = UIAlertController(title: "คำถาม",message: "เนื้อจากสัตว์ชนิดใดมีปริมาณไขมันน้อยที่สุด", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "หมู", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "เป็ด", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "เนื้อวัว", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "ปลา", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 6:
                let alertController = UIAlertController(title: "คำถาม",message: "สารอาหารชนิดใดช่วยเสริมสร้างกระดูก", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "แคลเซียม", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.addAction(UIAlertAction(title: "โปรตีน", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "วิตามิน", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "คาร์โบไฮเดรต", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 7:
                let alertController = UIAlertController(title: "คำถาม",message: "การออกกำลังกายประเภทใดที่เหมาะสมกับผู้สูงอายุ", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "วิ่ง", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "การเดิน", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.addAction(UIAlertAction(title: "โยคะ", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "แอโลบิก", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 8:
                let alertController = UIAlertController(title: "คำถาม",message: "ผู้สูงอายุควรลดปริมาณอะไรมากที่สุด", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "โซเดียมหรือเกลือ", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.addAction(UIAlertAction(title: "นำ้ตาล", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "วิตามิน", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "ไขมัน", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 9:
                let alertController = UIAlertController(title: "คำถาม",message: "ผู้สูงอายุควรดื่มน้ำให้เพียงพออย่างน้อยวันละกี่แก้ว", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "4-5 แก้ว", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "6-8 แก้ว", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.addAction(UIAlertAction(title: "5-6 แก้ว", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "8-10 แก้ว", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 10:
                let alertController = UIAlertController(title: "คำถาม",message: "อาหารในข้อใดมีประโยชน์ต่อผู้สูงอายุมากที่สุด", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "นมเปรี้ยว", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "สเต็กโคขุน", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "ปลานึ่ง", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.addAction(UIAlertAction(title: "ต้มยำกุ้ง", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 11:
                let alertController = UIAlertController(title: "คำถาม",message: "ผู้สูงอายุไม่ควรกินไข่แดงเพราะอะไร", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "ไม่สะอาด", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "ไม่มีประโยชน์", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "ก่อมะเร็ง", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "คอเลสเตอรอลสูง", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 12:
                let alertController = UIAlertController(title: "คำถาม",message: "โรคเกาต์คือโรคเกี่ยวกับระบบอะไร", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "ระบบโรคกระดูกและข้อ  ", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.addAction(UIAlertAction(title: "ระบบประสาท", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "ระบบหายใจ", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "ระหมุนเวียนโลหิต", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 13:
                let alertController = UIAlertController(title: "คำถาม",message: "ค่านำ้ตาลในเลือดเท่าไรอยู่ในเกณฑ์ปกติ", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "มากกว่า 180", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "น้อยกว่า 100", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.addAction(UIAlertAction(title: "100 - 125", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "126 - 180", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 14:
                let alertController = UIAlertController(title: "คำถาม",message: "ข้อใดคืออาการของความดันโลหิตสูง", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "ปวดเข่า", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "เจ็บหลัง", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "ปวดฟัน", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "ปวดศีรษะ", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 15:
                let alertController = UIAlertController(title: "คำถาม",message: "ความดันปกติของผู้สูงอายุที่มีอายุอยู่ในช่วง 60-79 ปี คือข้อใด", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "140/90 มิลลิเมตรปรอท", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.addAction(UIAlertAction(title: "145/95 มิลลิเมตรปรอท", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "150/100 มิลลิเมตรปรอท", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "160/120 มิลลิเมตรปรอท", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 16:
                let alertController = UIAlertController(title: "คำถาม",message: "ปัจจัยเสี่ยงสำคัญที่ทำให้เกิดโรคความดันโลหิตสูงคือ", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "ขาดวิตามิน", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "อายุน้อย", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "น้ำหนักตัวเกินและโรคอ้วน", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.addAction(UIAlertAction(title: "คอเลสเตอรอลสูง", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 17:
                let alertController = UIAlertController(title: "คำถาม",message: "ข้อใดไม่ใช่สาเหตุที่ทำให้เกิดโรคเบาหวาน", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "กินหวานจัด", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "กินเค็มจัด", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.addAction(UIAlertAction(title: "กรรมพันธุ์", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "มีคอเลสเตอรอลสูง", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 18:
                let alertController = UIAlertController(title: "คำถาม",message: "ปัญหาการทรงตัวหรือหกล้มในผู้สูงอายุอาจเกิดได้จากหลายปัจจัย ยกเว้นข้อใด", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "ข้อเสื่อม", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "รับประทานอาหารครบ 5 หมู่", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.addAction(UIAlertAction(title: "ความดันโลหิต", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "หัวใจเต้นผิดจังหวะ", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 19:
                let alertController = UIAlertController(title: "คำถาม",message: "วิตามินชนิดใดช่วยบำรุงสายตา", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "วิตามินเอ", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.addAction(UIAlertAction(title: "วิตามินบี", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "วิตามินซี", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "วิตามินอี", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            case 20:
                let alertController = UIAlertController(title: "คำถาม",message: "วิตามินชนิดใดช่วยลดอาการเหน็บชา", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "วิตามินเอ", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "วิตามินซี", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "วิตามินอี", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (20)
                    incorrect()
                }))
                alertController.addAction(UIAlertAction(title: "วิตามินบี", style: .default, handler: { (alert: UIAlertAction!) -> Void in
                    self.item1 = 1
                    self.seconds = self.seconds + (40)
                    correct()
                }))
                alertController.view.tintColor = UIColor.brown
                alertController.view.backgroundColor = UIColor.cyan
                alertController.view.layer.cornerRadius = 25
                present(alertController, animated: true,completion: nil)
                break
                
            default:
                break
            }
            
        }
        self.itemtime.isHidden = true
        Random()
        
    }
    
    
    @IBAction func incorrect(_ sender: Any) {
       seconds -= 5
        
    }
    
    
    
    
    
}
