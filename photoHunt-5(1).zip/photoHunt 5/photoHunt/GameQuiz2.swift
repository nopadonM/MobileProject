//
//  GameQuiz2.swift
//  photoHunt
//
//  Created by student on 12/7/2561 BE.
//  Copyright © 2561 student. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class GameQuiz2: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let view = self.view as! SKView? {
            // Load the SKScene from 'GameScene.sks'
            if let scene = SKScene(fileNamed: "itemScene") {
                // Set the scale mode to scale to fit the window
                scene.scaleMode = .aspectFill
                
                // Present the scene
                view.presentScene(scene)
            }
            
            view.ignoresSiblingOrder = true
            
            view.showsFPS = true
            view.showsNodeCount = true
            outcome.isHidden = true
            Next.isHidden = true
            Random()
            
        }
    }
    
    @IBOutlet var Question: UILabel!
    @IBOutlet var ans1: UIButton!
    @IBOutlet var ans2: UIButton!
    @IBOutlet var ans3: UIButton!
    @IBOutlet var ans4: UIButton!
    @IBOutlet var outcome: UILabel!
    @IBOutlet var Next: UIButton!
    var CorrectAnswer = String()
    
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    func Random() {
        var RandomNumber = arc4random() % 20
        RandomNumber += 1
        switch (RandomNumber) {
        case 1:
            Question.text = "ผู้สูงอายุจำเป็นต้องออกกำลังอย่างต่อเนื่องและสม่ำเสมอ อย่างน้อยสัปดาหฺ์ละกี่ครั้ง"
            ans1.setTitle("สัปดาห์ละ 2-3 ครั้ง", for: UIControlState.normal)
            ans2.setTitle("สัปดาห์ละ 1-2 ครั้ง", for: UIControlState.normal)
            ans3.setTitle("สัปดาห์ละ 4-5 ครั้ง", for: UIControlState.normal)
            ans4.setTitle("สัปดาห์ละ 3-4 ครั้ง", for: UIControlState.normal)
            CorrectAnswer = "4"
            break
        case 2:
            Question.text = "โรคทาลัสซีเมียหรือเรียกอีกอย่างว่าโรคอะไร"
            ans1.setTitle("โรคโลหิตจาง", for: UIControlState.normal)
            ans2.setTitle("โรคไข้เลือดออก", for: UIControlState.normal)
            ans3.setTitle("โรคเบาหวาน", for: UIControlState.normal)
            ans4.setTitle("โรคไต", for: UIControlState.normal)
            CorrectAnswer = "1"
            break
        case 3:
            Question.text = "เบี้ยยังชีพผู้สูงอายุจะให้กับบุคคลที่มีอายุกี่ปีขึ้นไป "
            ans1.setTitle("50", for: UIControlState.normal)
            ans2.setTitle("55", for: UIControlState.normal)
            ans3.setTitle("60", for: UIControlState.normal)
            ans4.setTitle("65", for: UIControlState.normal)
            CorrectAnswer = "3"
            break
        case 4:
            Question.text = "ช่วงอายุ 70-79 ปี จะได้รับเบี้ยยังชีพผู้สูงอายุเท่าไร"
            ans1.setTitle("500 บาทต่อเดือน", for: UIControlState.normal)
            ans2.setTitle("600 บาทต่อเดือน", for: UIControlState.normal)
            ans3.setTitle("700 บาทต่อเดือน", for: UIControlState.normal)
            ans4.setTitle("800 บาทต่อเดือน", for: UIControlState.normal)
            CorrectAnswer = "3"
            break
        case 5:
            Question.text = "เนื้อจากสัตว์ชนิดใดมีปริมาณไขมันน้อยที่สุด"
            ans1.setTitle("หมู", for: UIControlState.normal)
            ans2.setTitle("เป็ด", for: UIControlState.normal)
            ans3.setTitle("เนื้อวัว", for: UIControlState.normal)
            ans4.setTitle("ปลา", for: UIControlState.normal)
            CorrectAnswer = "4"
            break
        case 6:
            Question.text = "สารอาหารชนิดช่วยเสริมสร้างกระดูก"
            ans1.setTitle("แคลเซียม", for: UIControlState.normal)
            ans2.setTitle("โปรตีน", for: UIControlState.normal)
            ans3.setTitle("วิตามิน", for: UIControlState.normal)
            ans4.setTitle("คาร์โบไฮเดรต", for: UIControlState.normal)
            CorrectAnswer = "1"
            break
        case 7:
            Question.text = "การออกกำลังกายประเภทใดที่เหมาะสมกับผู้สูงอายุ"
            ans1.setTitle("วิ่ง", for: UIControlState.normal)
            ans2.setTitle("การเดิน", for: UIControlState.normal)
            ans3.setTitle("โยคะ", for: UIControlState.normal)
            ans4.setTitle("แอโลบิก", for: UIControlState.normal)
            CorrectAnswer = "2"
            break
        case 8:
            Question.text = "ผู้สูงอายุควรลดปริมาณอะไรมากที่สุด"
            ans1.setTitle("โซเดียมหรือเกลือ", for: UIControlState.normal)
            ans2.setTitle("นำ้ตาล", for: UIControlState.normal)
            ans3.setTitle("วิตามิน", for: UIControlState.normal)
            ans4.setTitle("ไขมัน", for: UIControlState.normal)
            CorrectAnswer = "1"
            break
        case 9:
            Question.text = "ผู้สูงอายุควรดื่มน้ำให้เพียงพออย่างน้อยวันละกี่แก้ว"
            ans1.setTitle("4-5 แก้ว", for: UIControlState.normal)
            ans2.setTitle("6-8 แก้ว", for: UIControlState.normal)
            ans3.setTitle("5-6 แก้ว", for: UIControlState.normal)
            ans4.setTitle("8-10 แก้ว", for: UIControlState.normal)
            CorrectAnswer = "2"
            break
        case 10:
            Question.text = "อาหารในข้อใดมีประโยชน์ต่อผู้สูงอายุมากที่สุด"
            ans1.setTitle("นมเปรี้ยว", for: UIControlState.normal)
            ans2.setTitle("สเต็กโคขุน", for: UIControlState.normal)
            ans3.setTitle("ปลานึ่ง", for: UIControlState.normal)
            ans4.setTitle("ต้มยำกุ้ง", for: UIControlState.normal)
            CorrectAnswer = "3"
            break
        case 11:
            Question.text = "ผู้สูงอายุไม่ควรกินไข่แดงเพราะอะไร"
            ans1.setTitle("ไม่สะอาด", for: UIControlState.normal)
            ans2.setTitle("ไม่มีประโยชน์", for: UIControlState.normal)
            ans3.setTitle("ก่อมะเร็ง", for: UIControlState.normal)
            ans4.setTitle("คอเลสเตอรอลสูง", for: UIControlState.normal)
            CorrectAnswer = "4"
            break
        case 12:
            Question.text = "ผู้สูงอายุไม่ควรกินไข่แดงเพราะอะไร"
            ans1.setTitle("ไม่สะอาด", for: UIControlState.normal)
            ans2.setTitle("ไม่มีประโยชน์", for: UIControlState.normal)
            ans3.setTitle("ก่อมะเร็ง", for: UIControlState.normal)
            ans4.setTitle("คอเลสเตอรอลสูง", for: UIControlState.normal)
            CorrectAnswer = "4"
            break
        case 13:
            Question.text = "ผู้สูงอายุไม่ควรกินไข่แดงเพราะอะไร"
            ans1.setTitle("ไม่สะอาด", for: UIControlState.normal)
            ans2.setTitle("ไม่มีประโยชน์", for: UIControlState.normal)
            ans3.setTitle("ก่อมะเร็ง", for: UIControlState.normal)
            ans4.setTitle("คอเลสเตอรอลสูง", for: UIControlState.normal)
            CorrectAnswer = "4"
            break
        case 14:
            Question.text = "ผู้สูงอายุไม่ควรกินไข่แดงเพราะอะไร"
            ans1.setTitle("ไม่สะอาด", for: UIControlState.normal)
            ans2.setTitle("ไม่มีประโยชน์", for: UIControlState.normal)
            ans3.setTitle("ก่อมะเร็ง", for: UIControlState.normal)
            ans4.setTitle("คอเลสเตอรอลสูง", for: UIControlState.normal)
            CorrectAnswer = "4"
            break
        case 15:
            Question.text = "ผู้สูงอายุไม่ควรกินไข่แดงเพราะอะไร"
            ans1.setTitle("ไม่สะอาด", for: UIControlState.normal)
            ans2.setTitle("ไม่มีประโยชน์", for: UIControlState.normal)
            ans3.setTitle("ก่อมะเร็ง", for: UIControlState.normal)
            ans4.setTitle("คอเลสเตอรอลสูง", for: UIControlState.normal)
            CorrectAnswer = "4"
            break
        case 16:
            Question.text = "ผู้สูงอายุไม่ควรกินไข่แดงเพราะอะไร"
            ans1.setTitle("ไม่สะอาด", for: UIControlState.normal)
            ans2.setTitle("ไม่มีประโยชน์", for: UIControlState.normal)
            ans3.setTitle("ก่อมะเร็ง", for: UIControlState.normal)
            ans4.setTitle("คอเลสเตอรอลสูง", for: UIControlState.normal)
            CorrectAnswer = "4"
            break
        case 17:
            Question.text = "ผู้สูงอายุไม่ควรกินไข่แดงเพราะอะไร"
            ans1.setTitle("ไม่สะอาด", for: UIControlState.normal)
            ans2.setTitle("ไม่มีประโยชน์", for: UIControlState.normal)
            ans3.setTitle("ก่อมะเร็ง", for: UIControlState.normal)
            ans4.setTitle("คอเลสเตอรอลสูง", for: UIControlState.normal)
            CorrectAnswer = "4"
            break
        case 18:
            Question.text = "ผู้สูงอายุไม่ควรกินไข่แดงเพราะอะไร"
            ans1.setTitle("ไม่สะอาด", for: UIControlState.normal)
            ans2.setTitle("ไม่มีประโยชน์", for: UIControlState.normal)
            ans3.setTitle("ก่อมะเร็ง", for: UIControlState.normal)
            ans4.setTitle("คอเลสเตอรอลสูง", for: UIControlState.normal)
            CorrectAnswer = "4"
            break
        case 19:
            Question.text = "ผู้สูงอายุไม่ควรกินไข่แดงเพราะอะไร"
            ans1.setTitle("ไม่สะอาด", for: UIControlState.normal)
            ans2.setTitle("ไม่มีประโยชน์", for: UIControlState.normal)
            ans3.setTitle("ก่อมะเร็ง", for: UIControlState.normal)
            ans4.setTitle("คอเลสเตอรอลสูง", for: UIControlState.normal)
            CorrectAnswer = "4"
            break
        case 20:
            Question.text = "ผู้สูงอายุไม่ควรกินไข่แดงเพราะอะไร"
            ans1.setTitle("ไม่สะอาด", for: UIControlState.normal)
            ans2.setTitle("ไม่มีประโยชน์", for: UIControlState.normal)
            ans3.setTitle("ก่อมะเร็ง", for: UIControlState.normal)
            ans4.setTitle("คอเลสเตอรอลสูง", for: UIControlState.normal)
            CorrectAnswer = "4"
            break
            
        default:
            break
        }
    }
    func Hide(){
        outcome.isHidden = true
        Next.isHidden = true
    }
    func Unhidden(){
        outcome.isHidden = false
        Next.isHidden = false
    }
    @IBAction func Answer1Action(_ sender: Any) {
        Unhidden()
        if (CorrectAnswer == "1"){
            outcome.text = "คำตอบถูกต้อง!"
            ans2.isHidden = true
            ans3.isHidden = true
            ans4.isHidden = true
        }
        else {
            outcome.text = "คำตอบไม่ถูกต้อง!"
            ans2.isHidden = true
            ans3.isHidden = true
            ans4.isHidden = true
        }
    }
    @IBAction func Answer2Action(_ sender: Any) {
        Unhidden()
        if (CorrectAnswer == "2"){
            outcome.text = "คำตอบถูกต้อง!"
            ans1.isHidden = true
            ans3.isHidden = true
            ans4.isHidden = true
        }
        else {
            outcome.text = "คำตอบไม่ถูกต้อง!"
            ans1.isHidden = true
            ans3.isHidden = true
            ans4.isHidden = true
        }
    }
    @IBAction func Answer3Action(_ sender: Any) {
        Unhidden()
        if (CorrectAnswer == "3"){
            outcome.text =  "คำตอบถูกต้อง!"
            ans1.isHidden = true
            ans2.isHidden = true
            ans4.isHidden = true
        }
        else {
            outcome.text = "คำตอบไม่ถูกต้อง!"
            ans1.isHidden = true
            ans2.isHidden = true
            ans4.isHidden = true
        }
    }
    @IBAction func Answer4Action(_ sender: Any) {
        Unhidden()
        if (CorrectAnswer == "4"){
            outcome.text = "คำตอบถูกต้อง!"
            ans1.isHidden = true
            ans2.isHidden = true
            ans3.isHidden = true
        }
        else {
            outcome.text = "คำตอบไม่ถูกต้อง!"
            ans1.isHidden = true
            ans2.isHidden = true
            ans3.isHidden = true
        }
    }
    @IBAction func nextac(_ sender: Any) {
        Hide()
    }
    
    
    

    

}
